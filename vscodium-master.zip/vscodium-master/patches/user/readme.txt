store user patches at location patches/user and those will be applied to vscode source git by the scripts
